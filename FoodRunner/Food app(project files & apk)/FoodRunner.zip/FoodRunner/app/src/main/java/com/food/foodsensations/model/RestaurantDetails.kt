package com.food.foodsensations.model

data class RestaurantDetails(
    val foodId:String,
    val foodName:String,
    val foodCost:String


)
